from shutil import copyfile
src = "input/data_file.xlsx"
dst = "output/out.xlsx"
copyfile(src, dst)
